SET DATEFORMAT dmy
BULK INSERT a1703860.a1703860.[Entregan]
   FROM 'e:\wwwroot\a1703860\entregan (1).csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )