BULK INSERT a1703860.a1703860.[Proyectos]
   FROM 'e:\wwwroot\a1703860\proyectos (1).csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )