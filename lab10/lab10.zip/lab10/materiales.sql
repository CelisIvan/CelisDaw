BULK INSERT a1703860.a1703860.[Materiales]
   FROM 'e:\wwwroot\a1703860\materiales (1).csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )